from django.http import HttpResponse
from django.shortcuts import render
from .models import CriminalCases

def webpage1(request):
    return render(request,'home.html')

def webpage2(request):
    return render(request,'map.html')
    
def webpage3(request):
    return render(request,'criminal_details.html')

def webpage4(request):
    data=CriminalCases.objects.all()
    return render(request,'case_details.html',{'data': data})

def cluster__1(request):
    return render(request,'cluster_-1_outer.html')
    
def cluster0(request):
    return render(request,'cluster_0_outer.html')
def cluster2(request):
    return render(request,'cluster_2_outer.html')    
def cluster5(request):
    return render(request,'cluster_5_outer.html')    
def cluster6(request):
    return render(request,'cluster_6_outer.html')    
def cluster8(request):
    return render(request,'cluster_8_outer.html')    
def cluster11(request):
    return render(request,'cluster_11_outer.html')
def cluster13(request):
    return render(request,'cluster_13_outer.html')

def dynamic(request):
    return render(request,'dynamic5.html')        
        
        
def generate_view_function(page_number):
    def view_function(request):
        return render(request, f'hotspot_{page_number}.html')
    return view_function


# Generate views dynamically
views = [generate_view_function(i) for i in range(0, 501)]
    