from flask import Flask, request, render_template
import pymysql  # You may need to install pymysql using pip install pymysql

app = Flask(__name__)

# Replace these database connection details with your own
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'crime',  # Replace with your actual database name
}

def connect_db():
    return pymysql.connect(**db_config)

@app.route('/', methods=['GET', 'POST'])
def insert_data():
    if request.method == 'POST':
        # Get form data
        criminalId = request.form["criminalId"]
        caseNumber = request.form["caseNumber"]
        dob = request.form["dob"]
        location = request.form["name"]
        crimeType = request.form["crimeType"]
        description = request.form["description"]
        arrestMade = request.form["arrestMade"]
        suspect = request.form["gender"]
        victimName = request.form["phone"]
        victimAge = request.form["address"]
        victimGender = request.form["markLocation"]
        policeBadgeNumber = request.form["markLocation1"]
        policeDesignation = request.form["markLocation2"]
        policeName = request.form["markLocation3"]
        lawyerName = request.form["markLocation4"]
        lawyerBarcodeId = request.form["markLocation5"]
        caseStatus = request.form["markLocation6"]

        # SQL query to insert data into the database
        sql = f"INSERT INTO criminal_details (criminalId, caseNumber, dob, location, crimeType, description, arrestMade, suspect, victimName, victimAge, victimGender, policeBadgeNumber, policeDesignation, policeName, lawyerName, lawyerBarcodeId, caseStatus) VALUES ('{criminalId}', '{caseNumber}', '{dob}', '{location}', '{crimeType}', '{description}', '{arrestMade}', '{suspect}', '{victimName}', '{victimAge}', '{victimGender}', '{policeBadgeNumber}', '{policeDesignation}', '{policeName}', '{lawyerName}', '{lawyerBarcodeId}', '{caseStatus}')"

        try:
            # Connect to the database
            connection = connect_db()

            with connection.cursor() as cursor:
                # Execute the SQL query
                cursor.execute(sql)

            # Commit changes to the database
            connection.commit()

            return "<p>Data inserted successfully!</p>"
        except Exception as e:
            return f"<p>Error: {e}</p>"
        finally:
            # Close the database connection
            connection.close()

    return render_template('case_details.html')  # Create a form.html file for your HTML form

if __name__ == '__main__':
    app.run(debug=True)