from django.db import models

class CriminalCases(models.Model):
    Criminal_ID=models.CharField(max_length=10 ,null=False,blank=False),
    Case_Number=models.CharField(max_length=10 ,null=False,blank=False),
    Date = models.DateTimeField(auto_now_add=True),
    Location=models.CharField(max_length=50 ,null=False,blank=False),
    Latitude =models.DecimalField(max_digits=9, decimal_places=4),
    Longitude =models.DecimalField(max_digits=9, decimal_places=4),
    Crime_Type =models.CharField(max_length=50 ,null=False,blank=False),
    Description =models.TextField(),
    Arrest_Made =models.CharField(max_length=3 ,null=False,blank=False),
    Suspect =models.CharField(max_length=50 ,null=False,blank=False),
    Victim_Name =models.CharField(max_length=10 ,null=False,blank=False),
    Victim_Age =models.IntegerField(),
    Victim_Gender =models.CharField(max_length=10 ,null=False,blank=False),
    Police_Badge_Number =models.CharField(max_length=10 ,null=False,blank=False),
    Police_Designation =models.CharField(max_length=20 ,null=False,blank=False),
    Police_Name =models.CharField(max_length=50 ,null=False,blank=False),
    Lawyer_Name =models.CharField(max_length=50 ,null=False,blank=False),
    Lawyer_Barcode_ID =models.CharField(max_length=50 ,null=False,blank=False),
    Case_Status =models.CharField(max_length=20 ,null=False,blank=False),
    
    def __str__(self):
        return slef.title
 
