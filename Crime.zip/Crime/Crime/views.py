# views.py

from django.shortcuts import render
from django.http import HttpResponse

def CaseD(request):
    if request.method == 'POST':
        # Process form data
        form_data = request.POST.get('form')  # Replace 'your_form_field' with the actual form field name

        # Your business logic for processing the form data goes here
        
        return HttpResponse('Form submitted successfully!')

    return render(request, 'case_details.html')
