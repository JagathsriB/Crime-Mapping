"""
URL configuration for Crime project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from .views import CaseD
from . import index


urlpatterns = [
    path('admin/', admin.site.urls),
    path('',index.webpage1,name='webpage1'),
    path(r'map/',index.webpage2,name='webpage2'),
    path(r'criminal_details/',index.webpage3,name='webpage3'),
    path(r'case_details/webpage/', index.webpage4, name='webpage4'),
    path(r'case_details/caseD/', CaseD, name='CaseD'),
    path(r'cluster_-1_outer/',index.cluster__1,name='cluster__1'),
    path(r'cluster_0_outer/',index.cluster0,name='cluster0'),
    path(r'cluster_2_outer/',index.cluster2,name='cluster2'),
    path(r'cluster_5_outer/',index.cluster5,name='cluster5'),
    path(r'cluster_6_outer/',index.cluster6,name='cluster6'),
    path(r'cluster_8_outer/',index.cluster8,name='cluster8'),
    path(r'cluster_11_outer/',index.cluster11,name='cluster11'),
    path(r'cluster_13_outer/',index.cluster13,name='cluster13'),
    path(r'dynamic5/',index.dynamic,name="dynamic"),
    
]

# Dynamically create URLs for hotspots and append to urlpatterns
for i in range(0, 501):  # Assuming you have 500 hotspots
    urlpatterns.append(path(f'hotspot_{i}/', index.generate_view_function(i), name=f'hotspot{i}'))

   
    


